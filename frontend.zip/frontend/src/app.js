import "./styles/global.css";
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/login";
import Register from "./pages/register";
import UserPreferences from "./pages/userPreferences";
import Recommendations from "./pages/recommendations";
import AdminDashboard from "./pages/adminDashboard";
import NotFound from "./pages/notFound";
import Navbar from "./components/navbar";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        console.log("✅ Firebase user:", user);
  
        setIsAuthenticated(true);
        setUserData({
          id: user.uid,
          email: user.email,
          name: "Test User", // force it
          avatar: "./person_icon.svg"
        });
  
      } else {
        console.log("❌ No user");
        setIsAuthenticated(false);
        setUserData(null);
      }
      setLoading(false);
    });
  
    return () => unsubscribe();
  }, []);
  
  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <Router>
      <Navbar 
        isAuthenticated={isAuthenticated} 
        userData={userData}
        setIsAuthenticated={setIsAuthenticated}
      />
      <Routes>
        <Route path="/" element={<UserPreferences isAuthenticated={isAuthenticated} />} />
        <Route 
          path="/login" 
          element={<Login setIsAuthenticated={setIsAuthenticated} setUserData={setUserData} />} 
        />
        <Route 
          path="/register" 
          element={<Register setIsAuthenticated={setIsAuthenticated} setUserData={setUserData} />} 
        />
        <Route path="/recommendations" element={<Recommendations isAuthenticated={isAuthenticated} />} />
        <Route path="/admin" element={<AdminDashboard isAuthenticated={isAuthenticated} />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
