import React, { useEffect, useState } from "react";
import "../styles/recommendations.css";
import { db } from "../firebase";
import { auth } from "../firebase";
import { doc, setDoc } from "firebase/firestore";

const Recommendations = () => {
  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("recommendations");
    if (stored) {
      setMovies(JSON.parse(stored));
    }
  }, []);

  const handleLike = async (movie) => {
    const user = auth.currentUser;
    if (user) {
      await setDoc(doc(db, "users", user.uid, "feedback", movie), {
        status: "liked",
        timestamp: new Date()
      });
    }
    setSelectedMovie(null);
  };

  const handleDislike = async (movie) => {
    const user = auth.currentUser;
    if (user) {
      await setDoc(doc(db, "users", user.uid, "feedback", movie), {
        status: "disliked",
        timestamp: new Date()
      });
    }
    setSelectedMovie(null);
  };

  return (
    <div className="recommendations-page">
      <div className="header-container">
        <h1 className="page-title">🎬 Your Movie Recommendations</h1>
        <p className="instruction-text">Click on a movie to see more details and provide feedback</p>
      </div>

      <div className="movies-grid">
        {movies.map((title, index) => (
          <div className="movie-row" key={index}>
            <div className="movie-card" onClick={() => setSelectedMovie(title)}>
              <img
                className="movie-poster"
                src={`https://image.tmdb.org/t/p/w500/${encodeURIComponent(title)}.jpg`}
                alt={title}
              />
              <p className="movie-title">{title}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedMovie && (
        <div className="movie-modal">
          <div className="modal-content">
            <button className="close-button" onClick={() => setSelectedMovie(null)}>
              ×
            </button>
            <div className="modal-poster">
              <img src={`https://image.tmdb.org/t/p/w500/${encodeURIComponent(selectedMovie)}.jpg`} alt={selectedMovie} />
            </div>
            <div className="modal-details">
              <h2>{selectedMovie}</h2>
              <div className="meta">Genre, Year, etc. (to be enhanced)</div>
              <div className="description">
                More movie description or metadata will go here once integrated.
              </div>
              <div className="action-buttons">
                <button className="like-button" onClick={() => handleLike(selectedMovie)}>
                  👍 Like
                </button>
                <button className="dislike-button" onClick={() => handleDislike(selectedMovie)}>
                  👎 Dislike
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Recommendations;
