import React from "react";
import "../styles/notFound.css";

function NotFound() {
  return <h1>❌ Page Not Found</h1>;
}

export default NotFound;
