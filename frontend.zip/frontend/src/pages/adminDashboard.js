import React from "react";
import "../styles/adminDashboard.css";

function AdminDashboard() {
  return <h1>🛠 Admin Dashboard</h1>;
}

export default AdminDashboard;
