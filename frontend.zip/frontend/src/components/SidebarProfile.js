import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { doc, updateDoc, collection, getDocs, deleteDoc } from 'firebase/firestore';
import { auth, storage, db } from '../firebase';
import personIcon from './person_icon.svg';

const SidebarProfile = ({ userData, onClose, onLogout }) => {
  console.log("🧩 SidebarProfile received:", userData);

  const [avatar, setAvatar] = useState(userData?.avatar || personIcon);
  const [isUploading, setIsUploading] = useState(false);
  const [likedMovies, setLikedMovies] = useState([]);
  const [dislikedMovies, setDislikedMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const fileInputRef = useRef(null);

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      setIsUploading(true);
      const user = auth.currentUser;

      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64Avatar = reader.result;
        setAvatar(base64Avatar);

        updateDoc(doc(db, 'users', user.uid), {
          avatar: base64Avatar
        });
      };

    } catch (error) {
      console.error('Error uploading avatar:', error);
    } finally {
      setIsUploading(false);
    }
  };

  useEffect(() => {
    const fetchFeedback = async () => {
      const user = auth.currentUser;
      if (user) {
        const feedbackRef = collection(db, "users", user.uid, "feedback");
        const snapshot = await getDocs(feedbackRef);
        const likes = [];
        const dislikes = [];

        snapshot.forEach(doc => {
          const data = doc.data();
          if (data.status === "liked") likes.push(doc.id);
          if (data.status === "disliked") dislikes.push(doc.id);
        });

        setLikedMovies(likes);
        setDislikedMovies(dislikes);
      }
    };

    fetchFeedback();
  }, []);

  const handleRemoveFeedback = async (movie) => {
    const user = auth.currentUser;
    if (user) {
      try {
        await deleteDoc(doc(db, "users", user.uid, "feedback", movie));
        setLikedMovies(likedMovies.filter(m => m !== movie));
        setDislikedMovies(dislikedMovies.filter(m => m !== movie));
      } catch (error) {
        console.error("❌ Failed to remove feedback:", error);
      }
    }
  };

  const renderMovieList = (list, label) => (
    <div className="sidebar-movie-list">
      <h3>{label}</h3>
      <div className="movie-thumbnails">
        {list.map((title, index) => (
          <div className="thumbnail" key={index}>
            <img
              src={`https://image.tmdb.org/t/p/w200/${encodeURIComponent(title)}.jpg`}
              alt={title}
              title={title}
              onClick={() => setSelectedMovie(title)}
            />
            <button onClick={() => handleRemoveFeedback(title)} className="remove-btn">✖</button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="user-profile">
      <div className="avatar-upload-container">
        <img 
          src={avatar} 
          alt="User" 
          className="user-avatar"
          onClick={() => fileInputRef.current.click()}
        />
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleAvatarUpload}
          accept="image/*"
          style={{ display: 'none' }}
        />
        {isUploading && <div className="upload-overlay">Uploading...</div>}
      </div>

      <h3>{userData?.name || 'User'}</h3>
      <p>{userData?.email || ''}</p>

      <Link to="/profile" className="profile-btn edit" onClick={onClose}>
        View Full Profile
      </Link>

      <button className="profile-btn logout" onClick={onLogout}>
        Log Out
      </button>

      {renderMovieList(likedMovies, "👍 Liked Movies")}
      {renderMovieList(dislikedMovies, "👎 Disliked Movies")}

      {selectedMovie && (
        <div className="movie-modal">
          <div className="modal-content">
            <button className="close-button" onClick={() => setSelectedMovie(null)}>
              ×
            </button>
            <div className="modal-poster">
              <img
                src={`https://image.tmdb.org/t/p/w500/${encodeURIComponent(selectedMovie)}.jpg`}
                alt={selectedMovie}
              />
            </div>
            <div className="modal-details">
              <h2>{selectedMovie}</h2>
              <div className="meta">Genre, Year, etc. (to be enhanced)</div>
              <div className="description">
                More movie description or metadata will go here once integrated.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SidebarProfile;
